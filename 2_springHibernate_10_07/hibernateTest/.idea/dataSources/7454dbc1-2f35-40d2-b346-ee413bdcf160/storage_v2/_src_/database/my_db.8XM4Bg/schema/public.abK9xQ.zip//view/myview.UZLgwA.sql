create view myview as
  SELECT weather.city, weather.temp_lo, weather.temp_hi, weather.prcp, weather.date, cities.location
  FROM weather,
       cities
  WHERE ((weather.city) :: text = (cities.name) :: text);

alter table myview
  owner to postgres;

